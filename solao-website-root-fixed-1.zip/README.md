# Solao Website

This is the official Solao clothing brand website.

## Features
- Urban/fine streetwear design
- Product catalog with 6 items
- Add-to-cart and manual order functionality
- Built with Next.js, TailwindCSS, and Framer Motion

## How to run locally
1. Clone the repository
2. Install dependencies: npm install
3. Run development server: npm run dev
4. Open http://localhost:3000

## Deployment
- Can be deployed to Vercel
- Manual order process (no Stripe or payment integration)